// function Admin(username, password){
//     this.username = username;
//     this.password = password;
//     this.login = function (){
//         return this.username
//     }
// }
// let admin = new Admin('erico', 123)
// admin.username = "erico";
// console.log(admin.login(admin.username));

//import Users from "./src/dom";


function Admin(email, password) {
	this.email = email;
	this.password = password;
	// this.logout = function(){
	// 	return this.email
	};

Admin.prototype.login = function (){
    console.log(`${this.email} has logged in`)

};
 Admin.prototype.logout = function() {
    console.log('${this.email} has logged out')
}
function Supadmin(email, password, title){
Admin.call(this, email, password)
this.title = title;
}

Supadmin.prototype = Object.create(Admin.prototype)
Supadmin.prototype.deleteUser = function (){
    console.log(`${this.email} has been deleted`)
}
let admin = new Admin("nana@gmail.com", "124");
let supadmin = new Supadmin("supadmin@gmail.com", "343", "supadmin had the black title");
supadmin.login()

admin.email = "squarsh@gmail.com";
admin.login()
supadmin.deleteUser();
function query(){
    this.title 
}
query.title
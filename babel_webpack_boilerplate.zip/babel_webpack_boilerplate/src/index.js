// import {styleBody, addTitle, contact} from './dom';

// console.log('index file');

// addTitle("test");
// styleBody();
// console.log(contact);
import users, { getPremiumUSers, myPremUsers } from './data';
import {Fruits, addTitle, styleBody} from './dom';

const premUsers = getPremiumUSers(users);
addTitle("Helloo")
console.log("Welcome")
styleBody();
console.log(premUsers);
let myPrem = myPremUsers(users)
console.log(myPrem)
console.log("I love u")
console.log("Hello there")

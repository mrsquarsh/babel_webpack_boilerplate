const users = [
    {name: 'mario', premium: true},
    {name: 'luigi', premium: false},
    {name: 'yoshi', premium: true},
    {name: 'toad', premium: true},
    {name: 'peach', premium: false}
];

let getPremiumUSers = (users)=>{
return users.filter(user => user.premium)
};


let myPremUsers = function(users){
return  users.filter(user =>  user.premium)
};
export {getPremiumUSers, myPremUsers, users as default}
